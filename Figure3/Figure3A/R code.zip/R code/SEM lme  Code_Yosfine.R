#install.packages("piecewiseSEM")
library(nlme)
library(piecewiseSEM)
library(car)
library(lmtest)
library(semTools)
library(bestNormalize)
setwd("C:/Users/jie liang/Downloads/Yosfina")
source("plot_Interpolated_Data.R")
path="SEM model data_Yosfine.xlsx"
climate_df<- read_excel(path, sheet = "Climate")
algae_df<- read_excel(path, sheet = "algae")
response_df<- read_excel(path, sheet = "response")

row_sums <- rowSums(algae_df[, 2:5])

# Calculate the percentage for each value in columns 2 to 5
algae_df[, 2:5] <- sweep(algae_df[, 2:5], 1, row_sums, FUN = "/") * 100
head(algae_df)
colnames(climate_df)
age_interp <- seq(100, 14000, by=300)
EDC_D.interp <- interp.dataset(y=climate_df[,c(2,2)], x=climate_df$Age_EDC_D, xout=age_interp, method=c("sspline"), rep.negt=FALSE)
# Now call the function TO check interpolation 
plot_Interpolated_Data(climate_df[,c(1)], climate_df[,c(2)],age_interp, EDC_D.interp[,1])

df=climate_df[,3:4]
df <- df[complete.cases(df), ]
PBIPSO25.interp <- interp.dataset(y=df[,c(2,2)], x=df$age, xout=age_interp, method=c("sspline"))
colnames(algae_df)
algae.interp<- interp.dataset(y=algae_df[,c(2:5)], x=algae_df$age, xout=age_interp, method=c("sspline"))
colnames(algae_df)

df1=response_df[,1:4]
df1 <- df1[complete.cases(df1), ]
colnames(response_df)
Ba.Fe.interp<- -interp.dataset(y=abs(df1[,c(2,2)]), x=df1$age, xout=age_interp, method=c("sspline"))
methylotrophs.interp<- interp.dataset(y=df1[,c(3,4)], x=df1$age, xout=age_interp, method=c("sspline"))
CO2_ppmv.interp<- interp.dataset(y=response_df[,c(6,6)], x=response_df$Gas_age_a_BP, xout=age_interp, method=c("sspline"))

# Now call the function TO check interpolation 
EDC_D_P=plot_Interpolated_Data(climate_df[,c(1)], climate_df[,c(2)],age_interp, EDC_D.interp[,1])
IS25_P=plot_Interpolated_Data(df[,c(1)], df[,c(2)],age_interp, PBIPSO25.interp[,1])
algae_P1=plot_Interpolated_Data(algae_df[,c(1)],algae_df[,c(2)],age_interp, algae.interp[,1])
algae_P2=plot_Interpolated_Data(algae_df[,c(1)],algae_df[,c(3)],age_interp, algae.interp[,2])
algae_P3=plot_Interpolated_Data(algae_df[,c(1)],algae_df[,c(4)],age_interp, algae.interp[,3])
algae_P4=plot_Interpolated_Data(algae_df[,c(1)],algae_df[,c(5)],age_interp, algae.interp[,4])
Ba.Fe_P=plot_Interpolated_Data(response_df[,c(1)],response_df[,c(2)],age_interp, Ba.Fe.interp[,1])
methylotrophs_p1=plot_Interpolated_Data(response_df[,c(1)],response_df[,c(3)],age_interp, methylotrophs.interp[,1])
methylotrophs_p2=plot_Interpolated_Data(response_df[,c(1)],response_df[,c(4)],age_interp, methylotrophs.interp[,2])
CO2__p=plot_Interpolated_Data(response_df[,c(5)],response_df[,c(6)],age_interp, CO2_ppmv.interp[,1])


###prepare for SEM-------------

dataset=data.frame(age_interp,EDC_D.interp[,1],PBIPSO25.interp[,1],
                   algae.interp,Ba.Fe.interp[,1],methylotrophs.interp,CO2_ppmv.interp[,1])

colnames(dataset)=c("age","EDC_D","IPSO25","Chaetoceros","Fragilariopsis","Micromonas"  ,"Phaeocystis","Ba.Fe","sumcount_of_methylotrophs",
                    "percentage_of_methylotrophs","CO2_ppmv")
## log translation---------------------------
dataset$Chaetoceros_log=log(dataset$Chaetoceros+1)
dataset$Fragilariopsis_log=log(dataset$Fragilariopsis+1)
dataset$Phaeocystis_log=log(dataset$Phaeocystis+1)
dataset$EDC_D=log_x(dataset$EDC_D)$x.t
colnames(dataset)
##
a1=ggplot(dataset,aes(x = Chaetoceros, y = CO2_ppmv)) + geom_smooth(method='lm')+geom_point() 
a2=ggplot(dataset,aes(x = Fragilariopsis, y = CO2_ppmv)) + geom_smooth(method='lm')+geom_point() 
a3=ggplot(dataset,aes(x = Phaeocystis, y = CO2_ppmv)) + geom_smooth(method='lm')+geom_point() 
a4=ggplot(dataset,aes(x = Micromonas, y = CO2_ppmv)) + geom_smooth(method='lm')+geom_point() 
grid.arrange(a1,a2,a3,a4, ncol = 2)


a1=ggplot(dataset,aes(x = Chaetoceros_log, y = CO2_ppmv)) + geom_smooth(method='lm')+geom_point() 
a2=ggplot(dataset,aes(x = Fragilariopsis_log, y = CO2_ppmv)) + geom_smooth(method='lm')+geom_point() 
a3=ggplot(dataset,aes(x = Phaeocystis_log, y = CO2_ppmv)) + geom_smooth(method='lm')+geom_point() 
a4=ggplot(dataset,aes(x = Micromonas_log, y = CO2_ppmv)) + geom_smooth(method='lm')+geom_point() 
grid.arrange(a1,a2,a3,a4, ncol = 2)

a5=ggplot(dataset,aes(y = Phaeocystis, x = age))+geom_point()
a5
grid.arrange(a3,a5, ncol = 2)
a1=ggplot(dataset,aes(x = Chaetoceros, y = percentage_of_methylotrophs)) + geom_smooth(method='lm')+geom_point() 
a2=ggplot(dataset,aes(x = Fragilariopsis, y =percentage_of_methylotrophs)) + geom_smooth(method='lm')+geom_point() 
a3=ggplot(dataset,aes(x = Phaeocystis, y = percentage_of_methylotrophs)) + geom_smooth(method='lm')+geom_point() 
a4=ggplot(dataset,aes(x = Micromonas, y = percentage_of_methylotrophs)) + geom_smooth(method='lm')+geom_point() 
grid.arrange(a1,a2,a3,a4, ncol = 2)

a1=ggplot(dataset,aes(x = Chaetoceros, y = Ba.Fe)) + geom_smooth(method='lm')+geom_point() 
a2=ggplot(dataset,aes(x = Fragilariopsis, y =Ba.Fe)) + geom_smooth(method='lm')+geom_point() 
a3=ggplot(dataset,aes(x = Phaeocystis, y = Ba.Fe)) + geom_smooth(method='lm')+geom_point() 
a4=ggplot(dataset,aes(x = Micromonas, y = Ba.Fe)) + geom_smooth(method='lm')+geom_point() 
grid.arrange(a1,a2,a3,a4, ncol = 2)

#Run Primary GLMs for each hypothesized path
##lme model
model1 <- lme(Chaetoceros_log ~ EDC_D + IPSO25, random = ~ 1 | age, data = dataset)
model2 <- lme(Fragilariopsis_log ~ EDC_D + IPSO25, random = ~ 1 | age, data = dataset)
model3 <- lme(Phaeocystis_log ~ EDC_D + IPSO25, random = ~ 1 | age, data = dataset)
#model4 <- lme(Micromonas_log ~ EDC_D + IPSO25, random = ~ 1 | age, data = dataset)
model5 <- lme(percentage_of_methylotrophs ~ Phaeocystis_log + Fragilariopsis_log + Chaetoceros_log, random = ~ 1 | age, data = dataset)
model6 <- lme(Ba.Fe ~ Phaeocystis_log + Fragilariopsis_log + Chaetoceros_log, random = ~ 1 | age, data = dataset)
model7 <- lme(CO2_ppmv ~ Phaeocystis_log + Fragilariopsis_log + Chaetoceros_log, random = ~ 1 | age, data = dataset)

sem_model.1 <- psem(model1, model2, model3, model5,model6,model7, data=dataset)
s=summary(sem_model.1, standardize = "none", conserve = TRUE)
s$ChiSq;s$Cstat
s
#Add our correlated error
s2=summary(update(sem_model.1, Phaeocystis_log %~~% Fragilariopsis_log,Phaeocystis_log %~~% Chaetoceros_log,Fragilariopsis_log %~~% Chaetoceros_log ), standardize="none")
s2$ChiSq;s2$Cstat
s2
#Update the model with the newly modified path
model5 <- lme(percentage_of_methylotrophs ~ Phaeocystis_log + Fragilariopsis_log + Chaetoceros_log+IPSO25, random = ~ 1 | age, data = dataset)
model6 <- lme(Ba.Fe ~ Phaeocystis_log + Fragilariopsis_log + Chaetoceros_log+percentage_of_methylotrophs, random = ~ 1 | age, data = dataset)
model7 <- lme(CO2_ppmv ~ Phaeocystis_log + Fragilariopsis_log + Chaetoceros_log+ Ba.Fe, random = ~ 1 | age, data = dataset)

sem_model.3=psem(model1, model2, model3, model5,model6,model7,Phaeocystis_log %~~% Fragilariopsis_log,Fragilariopsis_log %~~% Chaetoceros_log)
s3=summary(sem_model.3, standardize= "scale")
s3$ChiSq;s3$Cstat
s3
plot(sem_model.2,title="lme SEM")

