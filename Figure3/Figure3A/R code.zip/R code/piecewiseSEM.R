#install.packages("piecewiseSEM")
library(nlme)
library(piecewiseSEM)
library(car)
library(lmtest)
library(semTools)
setwd("C:/Users/jie liang/Downloads/Yosfina")
source("plot_Interpolated_Data.R")
path="SEM model data_Yosfine.xlsx"
climate_df<- read_excel(path, sheet = "Climate")
algae_df<- read_excel(path, sheet = "algae")
response_df<- read_excel(path, sheet = "response")

row_sums <- rowSums(algae_df[, 2:5])

# Calculate the percentage for each value in columns 2 to 5
algae_df[, 2:5] <- sweep(algae_df[, 2:5], 1, row_sums, FUN = "/") * 100
head(algae_df)
colnames(climate_df)
age_interp <- seq(100, 14000, by=300)
EDC_D.interp <- interp.dataset(y=climate_df[,c(2,2)], x=climate_df$Age_EDC_D, xout=age_interp, method=c("sspline"), rep.negt=FALSE)
# Now call the function TO check interpolation 
plot_Interpolated_Data(climate_df[,c(1)], climate_df[,c(2)],age_interp, EDC_D.interp[,1])

df=climate_df[,3:4]
df <- df[complete.cases(df), ]
PBIPSO25.interp <- interp.dataset(y=df[,c(2,2)], x=df$age, xout=age_interp, method=c("sspline"))
colnames(algae_df)
algae.interp<- interp.dataset(y=algae_df[,c(2:5)], x=algae_df$age, xout=age_interp, method=c("sspline"))
colnames(algae_df)



df1=response_df[,1:4]
df1 <- df1[complete.cases(df1), ]
colnames(response_df)
Ba.Fe.interp<- -interp.dataset(y=abs(df1[,c(2,2)]), x=df1$age, xout=age_interp, method=c("sspline"))
methylotrophs.interp<- interp.dataset(y=df1[,c(3,4)], x=df1$age, xout=age_interp, method=c("sspline"))
CO2_ppmv.interp<- interp.dataset(y=response_df[,c(6,6)], x=response_df$Gas_age_a_BP, xout=age_interp, method=c("sspline"))

# Now call the function TO check interpolation 
EDC_D_P=plot_Interpolated_Data(climate_df[,c(1)], climate_df[,c(2)],age_interp, EDC_D.interp[,1])
IS25_P=plot_Interpolated_Data(df[,c(1)], df[,c(2)],age_interp, PBIPSO25.interp[,1])
algae_P1=plot_Interpolated_Data(algae_df[,c(1)],algae_df[,c(2)],age_interp, algae.interp[,1])
algae_P2=plot_Interpolated_Data(algae_df[,c(1)],algae_df[,c(3)],age_interp, algae.interp[,2])
algae_P3=plot_Interpolated_Data(algae_df[,c(1)],algae_df[,c(4)],age_interp, algae.interp[,3])
algae_P4=plot_Interpolated_Data(algae_df[,c(1)],algae_df[,c(5)],age_interp, algae.interp[,4])
Ba.Fe_P=plot_Interpolated_Data(response_df[,c(1)],response_df[,c(2)],age_interp, Ba.Fe.interp[,1])
methylotrophs_p1=plot_Interpolated_Data(response_df[,c(1)],response_df[,c(3)],age_interp, methylotrophs.interp[,1])
methylotrophs_p2=plot_Interpolated_Data(response_df[,c(1)],response_df[,c(4)],age_interp, methylotrophs.interp[,2])
CO2__p=plot_Interpolated_Data(response_df[,c(5)],response_df[,c(6)],age_interp, CO2_ppmv.interp[,1])



###prepare for SEM-------------

dataset=data.frame(age_interp,EDC_D.interp[,1],PBIPSO25.interp[,1],
                   algae.interp,Ba.Fe.interp[,1],methylotrophs.interp,CO2_ppmv.interp[,1])

colnames(dataset)=c("age","EDC_D","IPSO25","Chaetoceros","Fragilariopsis","Micromonas"  ,"Phaeocystis","Ba.Fe","sumcount_of_methylotrophs",
                    "percentage_of_methylotrophs","CO2_ppmv")






#Breusch-Pagan test check heteroscedasticity
model_CO2 <- lm(CO2_ppmv ~ Chaetoceros + Fragilariopsis+Micromonas+Phaeocystis, data = dataset)
bp_test_CO2  <- bptest(model_CO2)
print(bp_test_CO2 )

model_methylotrophs <- lm(percentage_of_methylotrophs ~ Chaetoceros + Fragilariopsis+Micromonas+Phaeocystis, data = dataset)
bp_test_methylotrophs  <- bptest(model_methylotrophs)
print(bp_test_methylotrophs)


model_Ba.Fe <- lm(Ba.Fe ~ Chaetoceros + Fragilariopsis+Micromonas+Phaeocystis, data = dataset)
bp_test_Ba.Fe  <- bptest(model_Ba.Fe)
print(bp_test_Ba.Fe)
#If the p-value is less than a commonly used significance level (such as 0.05), it indicates the presence of heteroskedasticity.
colnames(dataset)
#glm-----------------
model1 <- glm(Chaetoceros ~ EDC_D + IPSO25, data = dataset, family = gaussian())
model2 <- glm(Fragilariopsis ~ EDC_D + IPSO25, data = dataset, family = gaussian())
model3 <- glm(Phaeocystis ~ EDC_D + IPSO25, data = dataset, family = gaussian())
model4 <- glm(Micromonas ~ EDC_D + IPSO25, data = dataset, family = gaussian())
model5 <- glm(percentage_of_methylotrophs ~Phaeocystis + Fragilariopsis + Chaetoceros+Micromonas, data = dataset, family = gaussian())
model6 <- glm(Ba.Fe ~ Phaeocystis + Fragilariopsis+ Chaetoceros+Micromonas, data = dataset, family = gaussian())
model7 <- glm(CO2_ppmv ~ Phaeocystis + Fragilariopsis+ Chaetoceros+Micromonas, data = dataset, family = gaussian())


all_models <- list(model1, model2, model3, model4, model5, model6, model7)

sem_model <- psem(model1, model2, model3, model4, model5, model6, model7,data=dataset)

summary(sem_model)

plot(sem_model)

###lme-----------------------
model1 <- lme(Chaetoceros ~ EDC_D + IPSO25, random = ~ 1 | age, data = dataset)
model2 <- lme(Fragilariopsis ~ EDC_D + IPSO25, random = ~ 1 | age, data = dataset)
model3 <- lme(Phaeocystis ~ EDC_D + IPSO25, random = ~ 1 | age, data = dataset)
model4 <- lme(Micromonas ~ EDC_D + IPSO25, random = ~ 1 | age, data = dataset)
model5 <- lme(percentage_of_methylotrophs ~ Phaeocystis + Fragilariopsis + Chaetoceros + Micromonas, random = ~ 1 | age, data = dataset)
model6 <- lme(Ba.Fe ~ Phaeocystis + Fragilariopsis + Chaetoceros + Micromonas, random = ~ 1 | age, data = dataset)
model7 <- lme(CO2_ppmv ~ Phaeocystis + Fragilariopsis + Chaetoceros + Micromonas, random = ~ 1 | age, data = dataset)

all_models <- list(model1, model2, model3, model4, model5, model6, model7)
sem_model <- psem(model1, model2, model3, model4, model5, model6, model7,data=dataset)

summary(sem_model)

plot(sem_model,title="gls SEM")

## log translation
dataset$Chaetoceros_log=log(dataset$Chaetoceros+1)
dataset$Fragilariopsis_log=log(dataset$Fragilariopsis+1)
dataset$Phaeocystis_log=log(dataset$Phaeocystis+1)
##lme model
model1 <- lme(Chaetoceros_log ~ EDC_D + IPSO25, random = ~ 1 | age, data = dataset)
model2 <- lme(Fragilariopsis_log ~ EDC_D + IPSO25, random = ~ 1 | age, data = dataset)
model3 <- lme(Phaeocystis_log ~ EDC_D + IPSO25, random = ~ 1 | age, data = dataset)
#model4 <- lme(Micromonas ~ EDC_D + IPSO25, random = ~ 1 | age, data = dataset)
model5 <- lme(percentage_of_methylotrophs ~ Phaeocystis_log + Fragilariopsis_log + Chaetoceros_log, random = ~ 1 | age, data = dataset)
model6 <- lme(Ba.Fe ~ Phaeocystis_log , random = ~ 1 | age, data = dataset)
model7 <- lme(CO2_ppmv ~ Phaeocystis_log + Fragilariopsis_log + Chaetoceros_log, random = ~ 1 | age, data = dataset)

sem_model <- psem(model1, model2, model3, model5,model6,model7,data=dataset)

summary(sem_model)

plot(sem_model,title="lme SEM")

##gls modle-------------

model1 <- gls(Chaetoceros_log ~ EDC_D + IPSO25, data = dataset)
model2 <- gls(Fragilariopsis_log ~ EDC_D + IPSO25, data = dataset)
model3 <- gls(Phaeocystis_log ~ EDC_D + IPSO25, data = dataset)
model5 <- gls(percentage_of_methylotrophs ~ Phaeocystis_log + Chaetoceros_log, data = dataset)
model6 <- gls(Ba.Fe ~ Phaeocystis_log , data = dataset)
model7 <- gls(CO2_ppmv ~ Phaeocystis_log  + Chaetoceros_log, data = dataset)


sem_model <- psem(model1, model2, model3, model5, model6, model7)


summary(sem_model)
plot(sem_model,title="gls SEM")

