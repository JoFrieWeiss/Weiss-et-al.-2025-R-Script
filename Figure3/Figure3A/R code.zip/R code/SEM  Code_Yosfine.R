library("readxl")
library(tidyverse)
library(rioja)
library(lavaan)
library(AICcmodavg) 
library(lavaanPlot)
library(rcompanion)
library(bestNormalize)
library(semTools)
library(ggplot2)
library(gridExtra)

setwd("C:/Users/jie liang/Downloads/Yosfina")
source("lavaan.survey.R")
source("lavaan.modavg.R")
source("plot_Interpolated_Data.R")
path="SEM model data_Yosfine.xlsx"
climate_df<- read_excel(path, sheet = "Climate")
algae_df<- read_excel(path, sheet = "algae")
response_df<- read_excel(path, sheet = "response")


##interpolation---------------------
colnames(climate_df)
age_interp <- seq(100, 14000, by=300)
EDC_D.interp <- interp.dataset(y=climate_df[,c(2,2)], x=climate_df$Age_EDC_D, xout=age_interp, method=c("sspline"), rep.negt=FALSE)
# Now call the function TO check interpolation 
plot_Interpolated_Data(climate_df[,c(1)], climate_df[,c(2)],age_interp, EDC_D.interp[,1])

df=climate_df[,3:4]
df <- df[complete.cases(df), ]
PBIPSO25.interp <- interp.dataset(y=df[,c(2,2)], x=df$age, xout=age_interp, method=c("sspline"))
colnames(algae_df)
algae.interp<- interp.dataset(y=algae_df[,c(2:5)], x=algae_df$age, xout=age_interp, method=c("sspline"))
colnames(algae_df)




df1=response_df[,1:4]
df1 <- df1[complete.cases(df1), ]
colnames(response_df)
Ba.Fe.interp<- -interp.dataset(y=abs(df1[,c(2,2)]), x=df1$age, xout=age_interp, method=c("sspline"))
methylotrophs.interp<- interp.dataset(y=df1[,c(3,4)], x=df1$age, xout=age_interp, method=c("sspline"))
CO2_ppmv.interp<- interp.dataset(y=response_df[,c(6,6)], x=response_df$Gas_age_a_BP, xout=age_interp, method=c("sspline"))

# Now call the function TO check interpolation 
EDC_D_P=plot_Interpolated_Data(climate_df[,c(1)], climate_df[,c(2)],age_interp, EDC_D.interp[,1])
IS25_P=plot_Interpolated_Data(df[,c(1)], df[,c(2)],age_interp, PBIPSO25.interp[,1])
algae_P1=plot_Interpolated_Data(algae_df[,c(1)],algae_df[,c(2)],age_interp, algae.interp[,1])
algae_P2=plot_Interpolated_Data(algae_df[,c(1)],algae_df[,c(3)],age_interp, algae.interp[,2])
algae_P3=plot_Interpolated_Data(algae_df[,c(1)],algae_df[,c(4)],age_interp, algae.interp[,3])
algae_P4=plot_Interpolated_Data(algae_df[,c(1)],algae_df[,c(5)],age_interp, algae.interp[,4])
Ba.Fe_P=plot_Interpolated_Data(response_df[,c(1)],response_df[,c(2)],age_interp, Ba.Fe.interp[,1])
methylotrophs_p1=plot_Interpolated_Data(response_df[,c(1)],response_df[,c(3)],age_interp, methylotrophs.interp[,1])
methylotrophs_p2=plot_Interpolated_Data(response_df[,c(1)],response_df[,c(4)],age_interp, methylotrophs.interp[,2])
CO2__p=plot_Interpolated_Data(response_df[,c(5)],response_df[,c(6)],age_interp, CO2_ppmv.interp[,1])

library(cowplot)
combined_plot <- plot_grid(EDC_D_P, IS25_P, algae_P1, algae_P2, algae_P3,
                           algae_P4,  Ba.Fe_P, methylotrophs_p1, methylotrophs_p2,                            CO2__p, ncol = 3, labels = "AUTO")

final_plot <- ggdraw() +
  draw_plot(combined_plot) +
  draw_label("interpolation for 300yrs", fontface='bold', x = 0.5, y = 1.03, hjust = 0.5, vjust = 0.5, size = 20)
win.graph()
print(final_plot)

###prepare for SEM-------------

dataset=data.frame(age_interp,EDC_D.interp[,1],PBIPSO25.interp[,1],
                   algae.interp,Ba.Fe.interp[,1],methylotrophs.interp,CO2_ppmv.interp[,1])

colnames(dataset)=c("age","EDC_D","IPSO25","Chaetoceros","Fragilariopsis","Micromonas","Phaeocystis","Ba/Fe","sumcount_of_methylotrophs",
                    "percentage_of_methylotrophs","CO2_ppmv")
#########distribution 
win.graph()
par(mfrow = c(3,4))

for (i in 2:11) {
  plotNormalHistogram(dataset[,i],xlab = colnames(dataset[i]))
}

###normalize method--------------
y=dataset$Micromonas
# 使用bestNormalize函数进行转换推荐
result <- bestNormalize(y, method = "all")
result

# 初始化一个空的列表来存储结果
results_list <- list()

# 循环遍历数据集的每一列
for (i in 2:ncol(dataset)) {
  # 对每一列应用 bestNormalize 函数

  result <- bestNormalize(dataset[,i], method = "all")
  # min(result$norm_stats)
  # str(result$norm_stats)
  # 将结果添加到列表中
  min_value <- min(result$norm_stats)
  name_of_min_value <- names(result$norm_stats)[which.min(result$norm_stats)]
  
  results_list[[i]] <-  data.frame(a=name_of_min_value)
  colnames(results_list[[i]]) <- colnames(dataset)[i]
  
  
  
}

results_list


dataset$EDC_D_trans <- orderNorm(dataset$EDC_D)$x.t
dataset$IPSO25_trans <- log_x(dataset$IPSO25)$x.t
dataset$Chaetoceros_trans <- orderNorm(dataset$Chaetoceros)$x.t
dataset$Fragilariopsis_trans <- orderNorm(dataset$Fragilariopsis)$x.t
dataset$Micromonas_trans <- orderNorm(dataset$Micromonas)$x.t
dataset$Phaeocystis_trans <- orderNorm(dataset$Phaeocystis)$x.t
dataset$Ba_Fe_trans <- orderNorm(dataset$`Ba/Fe`)$x.t
dataset$sumcount_of_methylotrophs_trans<- boxcox(dataset$sumcount_of_methylotrophs)$x.t
dataset$percentage_of_methylotrophs_trans<- log_x(dataset$percentage_of_methylotrophs)$x.t
dataset$CO2_ppmv_trans<- double_reverse_log(dataset$CO2_ppmv)$x.t
colnames(dataset)
#########distribution 
par(mfrow = c(3,4))
for (i in 12:21) {
  plotNormalHistogram(dataset[,i],xlab = colnames(dataset[i]))
}
colnames(dataset)
##SEM-----
model_basic0 <- '
  # path
  Chaetoceros_trans ~ EDC_D_trans + IPSO25_trans
  Fragilariopsis_trans  ~ EDC_D_trans + IPSO25_trans
  Micromonas_trans ~ EDC_D_trans + IPSO25_trans
  Phaeocystis_trans~ EDC_D_trans + IPSO25_trans
  
  Ba_Fe_trans ~ Chaetoceros_trans + Fragilariopsis_trans + Micromonas_trans+Phaeocystis_trans
  percentage_of_methylotrophs_trans ~ Chaetoceros_trans + Fragilariopsis_trans + Micromonas_trans+Phaeocystis_trans
  CO2_ppmv_trans ~ Chaetoceros_trans + Fragilariopsis_trans +Micromonas_trans+Phaeocystis_trans
  Phaeocystis_trans  ~~Chaetoceros_trans
  Micromonas_trans  ~~Chaetoceros_trans
  Micromonas_trans  ~~Phaeocystis_trans
  Fragilariopsis_trans ~~ Chaetoceros_trans
  Phaeocystis_trans  ~~Fragilariopsis_trans
'
standardized_data <- as.data.frame(scale(dataset))
fit0 <- sem(model_basic0 , data=standardized_data,estimator="MLR")

summary(fit0, fit.measures = TRUE, standardized = TRUE)
#win.graph()
lavaanPlot(model = fit0, node_options = list(shape = "box", fontname = "Helvetica"), edge_options = list(color = "grey"), coefs =T)


fit_indices <- fitMeasures(fit0, c("chisq", "df", "pvalue", "rmsea", "cfi", "gfi", "srmr"))
fit_indices
mi1=modindices(fit0);print(mi1[mi1$mi>3.0,])
# Get R2 for models
inspect(fit0, "rsquare")
colnames(dataset)


###---improved model
model_impro<-'# path
  Chaetoceros_trans ~ EDC_D_trans + IPSO25_trans
  Fragilariopsis_trans  ~ EDC_D_trans + IPSO25_trans
  Micromonas_trans ~ IPSO25_trans
  Phaeocystis_trans~ EDC_D_trans + IPSO25_trans+CO2_ppmv_trans
  
  percentage_of_methylotrophs_trans ~  Micromonas_trans+Phaeocystis_trans
  CO2_ppmv_trans ~Micromonas_trans
  Phaeocystis_trans  ~~Chaetoceros_trans
  Micromonas_trans  ~~Chaetoceros_trans
  Micromonas_trans  ~~Phaeocystis_trans
  Fragilariopsis_trans ~~ Chaetoceros_trans
  Phaeocystis_trans  ~~Fragilariopsis_trans
   Ba_Fe_trans ~~ CO2_ppmv_trans   
'


standardized_data <- as.data.frame(scale(dataset))

fit1 <- sem(model_impro, data=dataset,estimator="MLR")

summary(fit1, fit.measures = TRUE, standardized = TRUE)
#win.graph()
lavaanPlot(model = fit1, node_options = list(shape = "box", fontname = "Helvetica"), edge_options = list(color = "grey"), coefs =T)

fit_indices <- fitMeasures(fit1, c("chisq", "df", "pvalue", "rmsea", "cfi", "gfi", "srmr"))
fit_indices
mi1=modindices(fit0);print(mi1[mi1$mi>3.0,])
# Get R2 for models
inspect(fit0, "rsquare")
###########inproved 2
model_impro2<-'# path
  Chaetoceros_trans ~ EDC_D_trans + IPSO25_trans
  Fragilariopsis_trans  ~ EDC_D_trans + IPSO25_trans
  Micromonas_trans ~ IPSO25_trans
  Phaeocystis_trans~ EDC_D_trans + IPSO25_trans#+CO2_ppmv_trans
  
  percentage_of_methylotrophs_trans ~ Micromonas_trans+Phaeocystis_trans
  
  CO2_ppmv_trans ~Micromonas_trans
  Phaeocystis_trans  ~~Chaetoceros_trans
  Micromonas_trans  ~~Chaetoceros_trans
  Micromonas_trans  ~~Phaeocystis_trans
  Fragilariopsis_trans ~~ Chaetoceros_trans
  Phaeocystis_trans  ~~Fragilariopsis_trans
     
'


standardized_data <- as.data.frame(scale(dataset))

fit2 <- sem(model_impro2, data=standardized_data,estimator="MLR")

summary(fit2, fit.measures = TRUE, standardized = TRUE)
#win.graph()
lavaanPlot(model = fit2, node_options = list(shape = "box", fontname = "Helvetica"), edge_options = list(color = "grey"), coefs =T)

fit_indices <- fitMeasures(fit2, c("chisq", "df", "pvalue", "rmsea", "cfi", "gfi", "srmr"))
fit_indices
mi1=modindices(fit2);print(mi1[mi1$mi>3.0,])
# Get R2 for models
inspect(fit2, "rsquare")

###improve 3---------
model_impro3<-'# path
  Chaetoceros_trans ~ EDC_D_trans + IPSO25_trans
  Fragilariopsis_trans  ~ EDC_D_trans + IPSO25_trans
  Micromonas_trans ~ IPSO25_trans
  Phaeocystis_trans~ EDC_D_trans + IPSO25_trans#+CO2_ppmv_trans
  
  percentage_of_methylotrophs_trans ~ Micromonas_trans+Phaeocystis_trans+ IPSO25_trans
  
  CO2_ppmv_trans ~Micromonas_trans
  Phaeocystis_trans  ~~Chaetoceros_trans
  Micromonas_trans  ~  Fragilariopsis_trans
  Fragilariopsis_trans ~~ Chaetoceros_trans
  Phaeocystis_trans  ~~Fragilariopsis_trans
  
'


standardized_data <- as.data.frame(scale(dataset))

fit3 <- sem(model_impro3, data=standardized_data,estimator="MLR")

summary(fit3, fit.measures = TRUE, standardized = TRUE)
#win.graph()
lavaanPlot(model = fit3, node_options = list(shape = "box", fontname = "Helvetica"), edge_options = list(color = "grey"), coefs =T)

fit_indices <- fitMeasures(fit3, c("chisq", "df", "pvalue", "rmsea", "cfi", "gfi", "srmr"))
fit_indices
mi1=modindices(fit3);print(mi1[mi1$mi>3.0,])
# Get R2 for models
inspect(fit3, "rsquare")

####Finnal model
model_impro4<-'# path
  Chaetoceros_trans ~ EDC_D_trans + IPSO25_trans
  Fragilariopsis_trans  ~ EDC_D_trans + IPSO25_trans
  Micromonas_trans ~ IPSO25_trans
  Phaeocystis_trans~ EDC_D_trans + IPSO25_trans#+CO2_ppmv_trans
  
  percentage_of_methylotrophs_trans ~ Phaeocystis_trans+ IPSO25_trans
  
  CO2_ppmv_trans ~Micromonas_trans
  Phaeocystis_trans  ~~Chaetoceros_trans
  Micromonas_trans  ~  Fragilariopsis_trans
  Fragilariopsis_trans ~~ Chaetoceros_trans
  Phaeocystis_trans  ~~Fragilariopsis_trans
  
  
'


standardized_data <- as.data.frame(scale(dataset))

fit4 <- sem(model_impro4, data=standardized_data,estimator="MLR")

summary(fit4, fit.measures = TRUE, standardized = TRUE)
#win.graph()
lavaanPlot(model = fit4, node_options = list(shape = "box", fontname = "Helvetica"), edge_options = list(color = "grey"), coefs =T)

fit_indices <- fitMeasures(fit4, c("chisq", "df", "pvalue", "rmsea", "cfi", "gfi", "srmr"))
fit_indices
mi1=modindices(fit4);print(mi1[mi1$mi>3.0,])
# Get R2 for models
inspect(fit4, "rsquare")

##deletdM----------
##SEM-----
model_basic0 <- '
  # path
  Chaetoceros_trans ~ EDC_D_trans + IPSO25_trans
  Fragilariopsis_trans  ~ EDC_D_trans + IPSO25_trans
  Phaeocystis_trans~ EDC_D_trans + IPSO25_trans
  Ba_Fe_trans ~ Chaetoceros_trans + Fragilariopsis_trans +Phaeocystis_trans
  percentage_of_methylotrophs_trans ~ Chaetoceros_trans + Fragilariopsis_trans + Phaeocystis_trans
  CO2_ppmv_trans ~ Chaetoceros_trans + Fragilariopsis_trans +Phaeocystis_trans
  Phaeocystis_trans  ~~Chaetoceros_trans
  Fragilariopsis_trans ~~ Chaetoceros_trans
  Phaeocystis_trans  ~~Fragilariopsis_trans
'
standardized_data <- as.data.frame(scale(dataset))
fit0 <- sem(model_basic0 , data=standardized_data,estimator="MLR")

summary(fit0, fit.measures = TRUE, standardized = TRUE)
#win.graph()
lavaanPlot(model = fit0, node_options = list(shape = "box", fontname = "Helvetica"), edge_options = list(color = "grey"), coefs =T)


fit_indices <- fitMeasures(fit0, c("chisq", "df", "pvalue", "rmsea", "cfi", "gfi", "srmr"))
fit_indices
mi1=modindices(fit0);print(mi1[mi1$mi>3.0,])
# Get R2 for models
inspect(fit0, "rsquare")
##impro1
model_imp1 <- '
  # path
  Chaetoceros_trans ~ EDC_D_trans
  Fragilariopsis_trans  ~ EDC_D_trans
  Phaeocystis_trans~ EDC_D_trans 
  Ba_Fe_trans ~ Chaetoceros_trans+EDC_D_trans#+Phaeocystis_trans
  percentage_of_methylotrophs_trans ~  Phaeocystis_trans
  CO2_ppmv_trans ~ Fragilariopsis_trans +Phaeocystis_trans+Chaetoceros_trans
  Phaeocystis_trans  ~~Chaetoceros_trans
  Fragilariopsis_trans ~~ Chaetoceros_trans
  Phaeocystis_trans  ~~Fragilariopsis_trans
#  IPSO25_trans  ~ percentage_of_methylotrophs_trans+Phaeocystis_trans+Chaetoceros_trans 
'
standardized_data <- as.data.frame(scale(dataset))
fit1<- sem(model_imp1 , data=dataset,estimator="MLR")

summary(fit1, fit.measures = TRUE, standardized = TRUE)
#win.graph()
lavaanPlot(model = fit1, node_options = list(shape = "box", fontname = "Helvetica"), edge_options = list(color = "grey"), coefs =T)


fit_indices <- fitMeasures(fit1, c("chisq", "df", "pvalue", "rmsea", "cfi", "gfi", "srmr"))
fit_indices
mi1=modindices(fit1);print(mi1[mi1$mi>3.0,])

# Get R2 for models
inspect(fit1, "rsquare")



##compare sem models
library(AICcmodavg) 
aictab.lavaan(list(fit0,fit1,fit2,fit3,fit4),c("basic","imp1","imp2","imp3","imp4"))
